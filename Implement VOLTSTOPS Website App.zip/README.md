# VOLTSTOPS

**PLUG IN DINE OUT.**

VoltStops is a luxury editorial EV travel platform concept combining charging
discovery, route planning, dining, hotels, cafés, dhabas, and travel content.
The current release is a static interactive demonstration. Listings, routes,
availability, prices, reservations, and payments are illustrative and are not
connected to live operators.

Founder: **Bhupinder Singh, CEO & Founder — Patiala, Punjab**

## Production status

- Framework: React 19 + TypeScript + Vite 8
- Styling: Tailwind CSS 4 plus the existing global CSS design system
- Routing: React Router 7, client-side SPA routing
- Production type: static frontend
- Production directory: `dist/`
- Server required: no
- Database required: no
- Runtime environment variables required: none
- External application APIs required: none
- Figma runtime required: no

The visual design, page structure, content, interactions, responsive behavior,
and animations remain in the application source. The production app does not
use Figma URLs, Figma asset delivery, or Figma-only browser services.

## Requirements

- Node.js 22 (documented in `.mise.toml`)
- npm 10+ or pnpm 10+

## Install and run

Using npm:

```bash
npm install
npm run dev
```

Using the repository's original package manager:

```bash
pnpm install
pnpm dev
```

The default local URL is `http://localhost:8443`. Set the shell variable
`PORT` before starting Vite if another local port is needed.

## Production build

Using npm:

```bash
npm install
npm run typecheck
npm run build
```

Using pnpm:

```bash
pnpm install --frozen-lockfile
pnpm typecheck
pnpm build
```

Preview the generated build:

```bash
npm run preview
```

Vite writes the deployable site to:

```text
dist/
├── .htaccess
├── index.html
├── robots.txt
├── sitemap.xml
└── assets/
```

Upload the **contents of `dist/`**, including the hidden `.htaccess` file, to
the document root of the domain.

## cPanel / Apache deployment

1. In cPanel, add the domain and note its document root. For a primary domain,
   this is commonly `public_html/`.
2. Point the domain's DNS to the hosting account:
   - use the hosting provider's `A` record value for the root domain; and
   - use either a matching `A` record or a `CNAME` to the root domain for
     `www`.
3. Enable SSL in cPanel (AutoSSL or Let's Encrypt) before launch.
4. Run `npm install`, `npm run typecheck`, and `npm run build` locally.
5. Open `dist/` and upload **everything inside it** to `public_html/` (or the
   configured document root). Do not upload the `dist` folder as an extra
   nested directory.
6. Ensure cPanel File Manager has **Show Hidden Files** enabled so `.htaccess`
   is uploaded.
7. Remove any default hosting `index.html` or `index.php` that would take
   precedence over the VoltStops `index.html`.
8. Visit `/`, `/about`, `/chargers`, `/plan`, and one nested URL such as
   `/journal/choosing-a-charger` directly in a fresh browser tab.
9. If the domain is not `voltstops.com`, replace that domain in
   `index.html`, `public/robots.txt`, and `public/sitemap.xml`, then rebuild.

### SPA routing

React Router routes must all return `index.html`. `public/.htaccess` is copied
into `dist/.htaccess` and provides this Apache fallback while allowing real
assets, `robots.txt`, and `sitemap.xml` to be served normally.

Apache must permit `.htaccess` overrides and have `mod_rewrite` enabled. Most
cPanel hosting enables both. If the host does not, ask the provider to route
all non-file requests to `/index.html`.

For Nginx, use the equivalent rule:

```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

## Environment variables and secrets

The current app requires no environment variables. `.env.example` is included
to document that fact.

There are no API keys, database credentials, payment credentials, or private
secrets in the frontend. Never put private keys into variables beginning with
`VITE_`; Vite embeds those values in browser JavaScript.

`PORT` is an optional local development/preview process variable only. It is
not used by the deployed static site.

## Backend and service requirements

No backend is currently connected.

| Feature | Current behavior | Production service needed for a live version |
| --- | --- | --- |
| Saved stops | Browser `localStorage` | Optional user account/database |
| Demo reservations | Browser `localStorage` only | Booking API, operator integration, database |
| Journey planner | Illustrative client-side experience | Routing, traffic, charger status, vehicle/energy model |
| Charger status | Explicitly not live | Charging-network/operator APIs |
| Payments | No transaction is attempted | PCI-compliant payment gateway and secure server |
| User profile | Local demo summary | Authentication and account backend |
| Newsletter | Validates email, then shows a demo notice | Email marketing/form endpoint |
| Partner enquiry | Validates fields, then shows a demo notice | Secure form/API endpoint and CRM/email delivery |
| Directions | Informational notice only | Maps/directions provider |
| Reviews | No invented reviews | Moderated reviews backend |
| Analytics | Not connected | Optional consent-aware analytics |

Do not describe these features as live until the required backend services,
security controls, privacy policy, and legal review exist.

## Project structure

```text
.
├── public/
│   ├── .htaccess
│   ├── robots.txt
│   ├── sitemap.xml
│   └── assets/
│       ├── logos/
│       └── social/
├── src/
│   ├── assets/
│   │   ├── fonts/
│   │   └── *.webp
│   ├── App.tsx
│   ├── components.tsx
│   ├── content.ts
│   ├── index.css
│   ├── main.tsx
│   ├── pages.tsx
│   └── vite-env.d.ts
├── .env.example
├── .gitignore
├── index.html
├── package.json
├── pnpm-lock.yaml
├── tsconfig.json
└── vite.config.ts
```

The source intentionally keeps the existing consolidated `components.tsx` and
`pages.tsx` modules. Splitting them solely for folder aesthetics would create
deployment risk without changing functionality.

## Complete application audit

### Routes and pages

| Route | Page component | Purpose |
| --- | --- | --- |
| `/` | `Home` | Cinematic landing page, discovery sections, planner entry |
| `/explore` | `Explore` | All demo stops |
| `/chargers` | `Explore` | Charger-focused directory |
| `/restaurants` | `Explore` | Restaurant/café/dhaba directory |
| `/hotels` | `Explore` | Hotel directory |
| `/map` | `Explore` | Directory with illustrative map visible |
| `/plan` | `Plan` | Five-stage journey and demo charging flow |
| `/charger/:slug` | `VenueDetail` | Charger detail |
| `/restaurant/:slug` | `VenueDetail` | Restaurant detail |
| `/hotel/:slug` | `VenueDetail` | Hotel detail |
| `/destination/:slug` | `VenueDetail` | Destination detail |
| `/journal` | `Journal` | Editorial index |
| `/journal/:slug` | `BlogArticle` | Editorial article |
| `/partners` | `Partners` | Partner information and enquiry preview |
| `/about` | `About` | Company and founder story |
| `/bookings` | `Bookings` | Browser-local demo reservations |
| `/profile` | `Profile` | Browser-local saved-stop summary |
| `/privacy` | `Legal` | Demonstration privacy notice |
| `/terms` | `Legal` | Demonstration terms notice |
| `*` | `NotFound` | Branded 404 route |

Venue slugs:

- `the-highway-table`
- `northbound-charge`
- `the-orchard-retreat`
- `fieldnotes-cafe`
- `the-scenic-detour`
- `saanjh-highway-dhaba`

Journal slugs:

- `the-future-of-the-ev-road-trip`
- `charge-eat-repeat`
- `delhi-to-amritsar-by-ev`
- `choosing-a-charger`

### Shared components

- `Shell`: app context, layout, navigation, metadata, toast, footer, mobile nav
- `Navbar`: desktop and keyboard-dismissable mobile navigation
- `Wordmark`: text-based VoltStops identity
- `Icon`: local inline SVG icon system
- `Metadata`: route-aware titles, descriptions, canonical URLs, Open Graph,
  Twitter metadata, and JSON-LD
- `Newsletter`: validated demo email form
- `Footer`: internal navigation, email, Instagram, and unavailable-channel notices
- `VenueCard`: venue image, facts, detail link, and local saved state
- `BlogCard`: article image, metadata, and article link
- `SectionHeading`: shared editorial section heading
- `TripPlanner`: validated planner inputs and route navigation
- `JourneyMap`: interactive illustrative SVG map
- `BookingModal`: focus-managed three-stage demo reservation modal

Page-local components are `Hero`, `JourneyExperience`, and `PartnerSection`.

### Assets

All frontend assets are local.

Rendered WebP images in `src/assets/`:

- `night-charge.webp`
- `india-road.webp`
- `hotel-pool.webp`
- `ev-plug-in.webp`
- `ev-charging-closeup.webp`
- `luxury-dining.webp`
- `forest-journey.webp`

Stable public branding assets:

- `public/assets/logos/voltstops-logo-detail.png`
- `public/assets/social/voltstops-brand-concept.jpeg`

Fonts in `src/assets/fonts/`:

- DM Serif Display regular and italic, Latin and Latin Extended WOFF2
- Manrope variable 400–800, Latin and Latin Extended WOFF2
- SIL Open Font License files for both families

The application no longer requests Google Fonts at runtime. Vite fingerprints
source assets during the build for safe long-term caching.

Icons are inline SVG paths inside `Icon`; no remote icon package is used.
Available names are `arrow`, `bolt`, `pin`, `menu`, `close`, `search`, `food`,
`bed`, `compass`, `clock`, `user`, `bookmark`, `check`, and `map`.

### Source and style files

- `src/main.tsx`: React browser entry point and global CSS import
- `src/App.tsx`: lazy route definitions and router provider
- `src/components.tsx`: shared components and browser-local platform state
- `src/pages.tsx`: all page-level views and interactions
- `src/content.ts`: typed demo venues, journal content, and repository helpers
- `src/index.css`: all design tokens, layout, typography, animations, and
  responsive behavior
- `src/vite-env.d.ts`: Vite TypeScript declarations
- `index.html`: production metadata and React mount point
- `vite.config.ts`: standard standalone Vite/React/Tailwind configuration

### Dependencies

Runtime:

- `react`: UI rendering and state
- `react-dom`: browser DOM renderer
- `react-router`: SPA routing, links, URL parameters, and nested routes

Development/build:

- `vite`: development server and static production bundler
- `typescript`: static type checking
- `@vitejs/plugin-react`: React JSX and Fast Refresh integration
- `tailwindcss`: Tailwind CSS 4 engine
- `@tailwindcss/vite`: Tailwind/Vite integration
- `oxfmt`: repository formatter
- `@types/node`, `@types/react`, `@types/react-dom`: TypeScript declarations

No component library, icon package, HTTP client, analytics SDK, maps SDK,
database SDK, authentication SDK, or payment SDK is installed.

### External connections

The built site only exposes user-initiated links to:

- Instagram: `https://www.instagram.com/volt_stops/`
- Email: `mailto:info@voltstops.com`
- Phone: `tel:+919971633972`

LinkedIn and YouTube controls deliberately show local “not connected” notices
instead of navigating. There are no frontend `fetch`, XMLHttpRequest, or
WebSocket calls.

### Forms and interactive elements

- Journey planner: required origin/destination, optional vehicle and charging
  preferences, then client-side route state
- Stop directory: search, category tabs, region selector, amenity filters, map
  toggle, and reset state
- Route map: selectable demo stops
- Charging flow: corridor selection, stop search, connector display, energy
  controls, payment-method preview, and local demo booking
- Booking modal: native date/time validation, connector selection, review,
  focus trap, Escape close, and browser-local save
- Partner form: required name, business, valid email, and business type; no
  submission leaves the browser
- Newsletter form: required browser-validated email; no submission leaves the
  browser
- Saved stops and bookings: persisted under
  `voltstops-saved` and `voltstops-demo-bookings`
- Privacy control: clears the two local storage keys
- Hero: rotating story controls and pause/play state
- Navigation: desktop links, mobile menu, bottom mobile navigation, skip link,
  and footer links

### Animations and responsive behavior

Animations include hero image drift/fade, text arrival, route flow, scroll-line
movement, image hover scaling, menu/button transitions, and supported
scroll-linked image parallax. `prefers-reduced-motion: reduce` disables
animation and transition effects.

Responsive CSS covers:

- large desktop enhancement at `1700px+`
- desktop/tablet transition at `1150px`
- tablet/mobile navigation and layout at `980px`
- phone layouts at `640px`

The mobile version includes a fixed bottom navigation, compact cards, stacked
forms/details, horizontally scrollable filters where needed, safe viewport
modal sizing, and no intentional horizontal page overflow.

## SEO files

- Static home metadata is in `index.html`.
- Route-aware metadata and JSON-LD are generated by `Metadata`.
- `public/robots.txt` permits indexing.
- `public/sitemap.xml` lists public discovery, venue, journal, company, and
  legal URLs.
- Images used in content have descriptive `alt` text.
- `public/assets/logos/voltstops-logo-detail.png` is the favicon.
- `public/assets/social/voltstops-brand-concept.jpeg` is the default social
  sharing image.

If the production domain changes, update the absolute domain in `index.html`,
`public/robots.txt`, and `public/sitemap.xml` before building.

## Performance notes

- Content pages are lazy-loaded by route.
- Display photography uses local WebP files.
- Duplicate unused JPEG source files have been removed.
- Below-the-fold card imagery uses native lazy loading.
- Hero/detail imagery retains eager/high-priority loading where visually
  necessary.
- Fonts are local WOFF2 files with `font-display: swap`.
- Vite minifies and fingerprints production CSS, JavaScript, fonts, and images.
- Apache configuration enables compression and immutable caching for
  fingerprinted/static assets.

## Figma Make files

The `.figma/make/` directory contains optional workspace lifecycle scripts for
the original authoring environment. It is **not imported by the application**
and is not required on external hosting. The production Vite configuration,
assets, fonts, routing, metadata, and runtime are all standalone.

Do not upload `.figma/`, `src/`, `node_modules/`, or configuration files to
`public_html`; upload only the contents of `dist/`.

## Pre-launch limitations

- Production privacy and terms need legal review.
- Demo venue data must not be presented as verified live data.
- Real booking, charger availability, routing, authentication, and payments do
  not exist and require dedicated secure backend services.
- Newsletter and partner enquiries are validated locally but not delivered.
- Browser-local data does not synchronize between devices and can be cleared
  by the user or browser.
